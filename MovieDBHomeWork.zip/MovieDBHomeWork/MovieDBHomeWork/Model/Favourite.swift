//
//  Favourite.swift
//  MovieDBHomeWork
//
//  Created by M A Hossan on 21/02/2022.
//

import Foundation
/*struct Movie1 {
    let title: String
    let overview: String
    let image: UIImage?
}*/
